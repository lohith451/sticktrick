package com.rss.restapi;

import java.util.ArrayList;
import java.sql.*;
import java.util.List;

public class HotelRepository {
	
	Connection con=null;
	
	
	public HotelRepository()
	{
		String url="jdbc:mysql://localhost:3306/restdb";
        String username="root";
        String password="sandy";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,username,password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public List<Hotel> getHotels()
	{
		List<Hotel> hotels=new ArrayList<Hotel>();
		String sql="select * from hotel";
		try {
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next())
			{
				Hotel h=new Hotel();
				h.setId(rs.getInt(1));
				h.setName(rs.getString(2));
				h.setItems(rs.getInt(3));
				hotels.add(h);
			
		}
     }
			
			catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return hotels;
	}
	
	public Hotel getHotel(int id)
	{
		String sql="select * from hotel where id="+id;
		Hotel h =new Hotel();
		try {
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(sql);
			if(rs.next())
			{
				
				h.setId(rs.getInt(1));
				h.setName(rs.getString(2));
				h.setItems(rs.getInt(3));
				
			
		    } 
		}
			catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return h;
	}

	public void create(Hotel h) {
		// TODO Auto-generated method stub
		String sql="insert into hotel values(?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.executeUpdate();
			ps.setInt(1,h.getId());
			ps.setString(2,h.getName());
			ps.setInt(3,h.getItems());
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	

}