package com.rss.restapi;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Hotel {
	
    int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	String name;
	int items;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getItems() {
		return items;
	}
	public void setItems(int items) {
		this.items = items;
	}
	@Override
	public String toString() {
		return "Hotel [name=" + name + ", items=" + items + "]";
	}
	
}