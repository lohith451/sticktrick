package com.rss.restapi;

import java.util.Arrays;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path ("jupiters")

public class JupiterResource {
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<Jupiter> getJupiter()
	{
		
		System.out.println("jupiter called");
		Jupiter j1=new Jupiter();
		j1.setName("buisnessman");
		j1.setPoints(50);
		
		
		Jupiter j2=new Jupiter();
		j2.setName("battle");
		j2.setPoints(40);
		
		List<Jupiter> jupiters=Arrays.asList(j1,j2);
		return jupiters;
		
	}

}
