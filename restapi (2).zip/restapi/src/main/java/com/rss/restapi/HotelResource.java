package com.rss.restapi;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path ("hotels")//URI
public class HotelResource {
	 HotelRepository repo=new  HotelRepository();
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Hotel> getHotels()
	{
		return repo.getHotels();
	}
	@GET
	@Path("hotel/15")
	@Produces(MediaType.APPLICATION_XML)
	public Hotel getHotel()
	{
		return repo.getHotel(15);
	}
	
	@POST
	@Path("hotel")
	@Produces(MediaType.APPLICATION_XML)
	
	public Hotel createHotel(Hotel h)
	{
		repo.create(h);
		return h;
	}
	
	
	
	

}


